set head off
select status from dba_registry where comp_id = 'APEX';
exit
